"use strict";
exports.id = 550;
exports.ids = [550];
exports.modules = {

/***/ 7550:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Fh: () => (/* binding */ getServerAuth),
/* harmony export */   Lz: () => (/* binding */ authOptions),
/* harmony export */   nX: () => (/* binding */ getAuthUser)
/* harmony export */ });
/* unused harmony exports hashPassword, comparePassword */
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6113);
/* harmony import */ var crypto__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(crypto__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3227);
/* harmony import */ var next_auth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7449);
/* harmony import */ var next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _db__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5495);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_db__WEBPACK_IMPORTED_MODULE_3__]);
_db__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const authOptions = {
    providers: [
        next_auth_providers_credentials__WEBPACK_IMPORTED_MODULE_2___default()({
            credentials: {
                username: {
                    type: "text",
                    label: "Username"
                },
                password: {
                    type: "password",
                    label: "Password"
                }
            },
            async authorize (credentials, req) {
                const { username, password } = credentials;
                const user = await _db__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.user.findFirst({
                    where: {
                        username: username
                    }
                });
                if (!user) throw new Error("NOT_FOUND");
                // if (!(await comparePassword(password, user.password))) throw new Error("WRONG_PASSWORD")
                return {
                    ...user,
                    password: ""
                };
            }
        })
    ],
    session: {
        strategy: "jwt",
        maxAge: 4 * 60 * 60,
        generateSessionToken: ()=>{
            return (0,crypto__WEBPACK_IMPORTED_MODULE_0__.randomUUID)?.() ?? (0,crypto__WEBPACK_IMPORTED_MODULE_0__.randomBytes)(32).toString("hex");
        }
    },
    pages: {
        signIn: "/join",
        signOut: "/join",
        error: "/join"
    },
    secret: process.env.NEXTAUTH_SECRET,
    callbacks: {
        async jwt ({ token, user }) {
            if (user) {
                token.user = user;
            }
            return token;
        },
        async session ({ session, token }) {
            if (token.user) {
                session.user = token.user;
            }
            return session;
        }
    }
};
const getServerAuth = (ctx)=>{
    if (ctx) return (0,next_auth__WEBPACK_IMPORTED_MODULE_1__.getServerSession)(ctx.req, ctx.res, authOptions);
    else return (0,next_auth__WEBPACK_IMPORTED_MODULE_1__.getServerSession)(authOptions);
};
const getAuthUser = async (session)=>{
    const currentSession = session !== undefined ? session : await getServerAuth();
    if (!currentSession) return null;
    return await _db__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z.user.findUnique({
        where: {
            id: currentSession.user.id
        }
    });
};
async function hashPassword(password) {
    try {
        return bcrypt.hash(password, 10);
    } catch (error) {
        return null;
    }
}
async function comparePassword(plainPassword, hashedPassword) {
    try {
        return bcrypt.compare(plainPassword, hashedPassword);
    } catch (error) {
        return false;
    }
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5495:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _env_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6205);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_env_mjs__WEBPACK_IMPORTED_MODULE_1__]);
_env_mjs__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


const globalForDB = globalThis;
const db = globalForDB.db ?? new _prisma_client__WEBPACK_IMPORTED_MODULE_0__.PrismaClient({
    log: _env_mjs__WEBPACK_IMPORTED_MODULE_1__/* .env */ .O.NODE_ENV === "development" ? [
        "query",
        "error",
        "warn"
    ] : [
        "error"
    ]
});
if (_env_mjs__WEBPACK_IMPORTED_MODULE_1__/* .env */ .O.NODE_ENV !== "production") globalForDB.db = db;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (db);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6205:
/***/ ((__webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(__webpack_module__, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   O: () => (/* binding */ env)
/* harmony export */ });
/* harmony import */ var _t3_oss_env_nextjs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6206);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9926);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_t3_oss_env_nextjs__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_1__]);
([_t3_oss_env_nextjs__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const env = (0,_t3_oss_env_nextjs__WEBPACK_IMPORTED_MODULE_0__.createEnv)({
    server: {
        DATABASE_URL: zod__WEBPACK_IMPORTED_MODULE_1__.z.string().url(),
        NODE_ENV: zod__WEBPACK_IMPORTED_MODULE_1__.z.enum([
            "development",
            "test",
            "production"
        ]),
        NEXTAUTH_SECRET:  true ? zod__WEBPACK_IMPORTED_MODULE_1__.z.string().min(1) : 0,
        NEXTAUTH_URL: zod__WEBPACK_IMPORTED_MODULE_1__.z.string().url(),
        BASE_URL: zod__WEBPACK_IMPORTED_MODULE_1__.z.string().url()
    },
    client: {
    },
    runtimeEnv: {
        DATABASE_URL: process.env.DATABASE_URL,
        NODE_ENV: "production",
        NEXTAUTH_SECRET: process.env.NEXTAUTH_SECRET,
        BASE_URL: process.env.BASE_URL,
        NEXTAUTH_URL: process.env.NEXTAUTH_URL
    },
    skipValidation: !!process.env.SKIP_ENV_VALIDATION
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;