"use strict";
(() => {
var exports = {};
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 3524:
/***/ ((module) => {

module.exports = require("@prisma/client");

/***/ }),

/***/ 2132:
/***/ ((module) => {

module.exports = require("@radix-ui/react-icons");

/***/ }),

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 3227:
/***/ ((module) => {

module.exports = require("next-auth");

/***/ }),

/***/ 7449:
/***/ ((module) => {

module.exports = require("next-auth/providers/credentials");

/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 730:
/***/ ((module) => {

module.exports = require("next/dist/server/api-utils/node.js");

/***/ }),

/***/ 3076:
/***/ ((module) => {

module.exports = require("next/dist/server/future/route-modules/route-module.js");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 5132:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/get-img-props.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 72:
/***/ ((module) => {

module.exports = require("superjson");

/***/ }),

/***/ 1656:
/***/ ((module) => {

module.exports = import("@hookform/resolvers/zod");;

/***/ }),

/***/ 49:
/***/ ((module) => {

module.exports = import("@radix-ui/react-label");;

/***/ }),

/***/ 4338:
/***/ ((module) => {

module.exports = import("@radix-ui/react-slot");;

/***/ }),

/***/ 6206:
/***/ ((module) => {

module.exports = import("@t3-oss/env-nextjs");;

/***/ }),

/***/ 272:
/***/ ((module) => {

module.exports = import("@trpc/client");;

/***/ }),

/***/ 7455:
/***/ ((module) => {

module.exports = import("@trpc/next");;

/***/ }),

/***/ 2937:
/***/ ((module) => {

module.exports = import("@trpc/server");;

/***/ }),

/***/ 6282:
/***/ ((module) => {

module.exports = import("@trpc/server/adapters/next");;

/***/ }),

/***/ 6926:
/***/ ((module) => {

module.exports = import("class-variance-authority");;

/***/ }),

/***/ 6593:
/***/ ((module) => {

module.exports = import("clsx");;

/***/ }),

/***/ 5641:
/***/ ((module) => {

module.exports = import("react-hook-form");;

/***/ }),

/***/ 8097:
/***/ ((module) => {

module.exports = import("tailwind-merge");;

/***/ }),

/***/ 9926:
/***/ ((module) => {

module.exports = import("zod");;

/***/ }),

/***/ 6113:
/***/ ((module) => {

module.exports = require("crypto");

/***/ }),

/***/ 6816:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   routeModule: () => (/* binding */ routeModule)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_pages_api_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6429);
/* harmony import */ var next_dist_server_future_route_modules_pages_api_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7153);
/* harmony import */ var next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7305);
/* harmony import */ var private_next_pages_api_trpc_trpc_ts__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2148);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([private_next_pages_api_trpc_trpc_ts__WEBPACK_IMPORTED_MODULE_3__]);
private_next_pages_api_trpc_trpc_ts__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];
// @ts-ignore this need to be imported from next/dist to be external



const PagesAPIRouteModule = next_dist_server_future_route_modules_pages_api_module__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule;
// Import the userland code.
// @ts-expect-error - replaced by webpack/turbopack loader

// Re-export the handler (should be the default export).
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_api_trpc_trpc_ts__WEBPACK_IMPORTED_MODULE_3__, "default"));
// Re-export config.
const config = (0,next_dist_build_webpack_loaders_next_route_loader_helpers__WEBPACK_IMPORTED_MODULE_2__/* .hoist */ .l)(private_next_pages_api_trpc_trpc_ts__WEBPACK_IMPORTED_MODULE_3__, "config");
// Create and export the route module that will be consumed.
const routeModule = new PagesAPIRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.PAGES_API,
        page: "/api/trpc/[trpc]",
        pathname: "/api/trpc/[trpc]",
        // The following aren't used in production.
        bundlePath: "",
        filename: ""
    },
    userland: private_next_pages_api_trpc_trpc_ts__WEBPACK_IMPORTED_MODULE_3__
});

//# sourceMappingURL=pages-api.js.map
__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1297:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports Button, buttonVariants */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4338);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6926);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9834);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _utils_common__WEBPACK_IMPORTED_MODULE_4__]);
([_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _utils_common__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const buttonVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__.cva)("inline-flex items-center justify-center rounded-md text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-slate-950 disabled:pointer-events-none disabled:opacity-50 dark:focus-visible:ring-slate-300", {
    variants: {
        variant: {
            default: "bg-gradient-to-l from-pink-500 to-red-500 text-slate-50 shadow hover:opacity-90",
            dark: "bg-slate-900 text-slate-50 shadow hover:bg-slate-900/90 dark:bg-slate-50 dark:text-slate-900 dark:hover:bg-slate-50/90",
            destructive: "bg-red-500 text-slate-50 shadow-sm hover:bg-red-500/90 dark:bg-red-900 dark:text-slate-50 dark:hover:bg-red-900/90",
            outline: "border border-slate-200 bg-transparent shadow-sm hover:bg-slate-100 hover:text-slate-900 dark:border-slate-800 dark:hover:bg-slate-800 dark:hover:text-slate-50",
            secondary: "bg-slate-100 text-slate-900 shadow-sm hover:bg-slate-100/80 dark:bg-slate-800 dark:text-slate-50 dark:hover:bg-slate-800/80",
            ghost: "hover:bg-slate-100 hover:text-slate-900 dark:hover:bg-slate-800 dark:hover:text-slate-50",
            link: "text-slate-900 underline-offset-4 hover:underline dark:text-slate-50"
        },
        size: {
            default: "h-9 px-4 py-2",
            sm: "h-8 rounded-md px-3 text-xs",
            lg: "h-10 rounded-md px-8",
            icon: "h-9 w-9"
        }
    },
    defaultVariants: {
        variant: "default",
        size: "default"
    }
});
const Button = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, variant, size, asChild = false, ...props }, ref)=>{
    const Comp = asChild ? _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__.Slot : "button";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Comp, {
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_4__.cn)(buttonVariants({
            variant,
            size,
            className
        })),
        ref: ref,
        ...props
    });
});
Button.displayName = "Button";


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7656:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports Card, CardHeader, CardFooter, CardTitle, CardDescription, CardContent */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9834);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_common__WEBPACK_IMPORTED_MODULE_2__]);
_utils_common__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Card = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("rounded-xl border border-slate-200 bg-white text-slate-950 shadow dark:border-slate-800 dark:bg-slate-950 dark:text-slate-50", className),
        ...props
    }));
Card.displayName = "Card";
const CardHeader = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("flex flex-col space-y-1.5 p-6", className),
        ...props
    }));
CardHeader.displayName = "CardHeader";
const CardTitle = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("font-semibold leading-none tracking-tight", className),
        ...props
    }));
CardTitle.displayName = "CardTitle";
const CardDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("text-sm text-slate-500 dark:text-slate-400", className),
        ...props
    }));
CardDescription.displayName = "CardDescription";
const CardContent = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("p-6 pt-0", className),
        ...props
    }));
CardContent.displayName = "CardContent";
const CardFooter = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("flex items-center p-6 pt-0", className),
        ...props
    }));
CardFooter.displayName = "CardFooter";


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2458:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9834);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_common__WEBPACK_IMPORTED_MODULE_2__]);
_utils_common__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



function ChipsGroup({ value, onChange, options }) {
    const [activeChip, setActiveChip] = useState(value);
    useEffect(()=>{
        if (activeChip) onChange?.(activeChip);
    }, [
        activeChip
    ]);
    useEffect(()=>{
        setActiveChip(value);
    }, [
        value
    ]);
    return /*#__PURE__*/ _jsx("div", {
        className: "flex items-center gap-4 px-3 py-2 border border-slate-200 rounded-md w-full",
        children: options?.map((opt)=>/*#__PURE__*/ _jsx("button", {
                type: "button",
                onClick: ()=>setActiveChip(opt),
                className: cn("outline-none border border-pink-500 px-5 py-1.5 rounded-md text-xs font-medium", opt === activeChip && "bg-gradient-to-l from-pink-500 to-red-500 text-white"),
                children: opt
            }, opt))
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6984:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony exports useFormField, Form, FormItem, FormLabel, FormControl, FormDescription, FormMessage, FormField */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4338);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9834);
/* harmony import */ var _components_ui_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7423);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _utils_common__WEBPACK_IMPORTED_MODULE_4__, _components_ui_label__WEBPACK_IMPORTED_MODULE_5__]);
([_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, _utils_common__WEBPACK_IMPORTED_MODULE_4__, _components_ui_label__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const Form = (/* unused pure expression or super */ null && (FormProvider));
const FormFieldContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.createContext({});
const FormField = ({ ...props })=>{
    return /*#__PURE__*/ _jsx(FormFieldContext.Provider, {
        value: {
            name: props.name
        },
        children: /*#__PURE__*/ _jsx(Controller, {
            ...props
        })
    });
};
const useFormField = ()=>{
    const fieldContext = react__WEBPACK_IMPORTED_MODULE_1__.useContext(FormFieldContext);
    const itemContext = react__WEBPACK_IMPORTED_MODULE_1__.useContext(FormItemContext);
    const { getFieldState, formState } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useFormContext)();
    const fieldState = getFieldState(fieldContext.name, formState);
    if (!fieldContext) {
        throw new Error("useFormField should be used within <FormField>");
    }
    const { id } = itemContext;
    return {
        id,
        name: fieldContext.name,
        formItemId: `${id}-form-item`,
        formDescriptionId: `${id}-form-item-description`,
        formMessageId: `${id}-form-item-message`,
        ...fieldState
    };
};
const FormItemContext = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.createContext({});
const FormItem = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>{
    const id = react__WEBPACK_IMPORTED_MODULE_1__.useId();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FormItemContext.Provider, {
        value: {
            id
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            ref: ref,
            className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_4__.cn)("space-y-2", className),
            ...props
        })
    });
});
FormItem.displayName = "FormItem";
const FormLabel = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>{
    const { error, formItemId } = useFormField();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_label__WEBPACK_IMPORTED_MODULE_5__/* .Label */ ._, {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_4__.cn)(className),
        htmlFor: formItemId,
        ...props
    });
});
FormLabel.displayName = "FormLabel";
const FormControl = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ ...props }, ref)=>{
    const { error, formItemId, formDescriptionId, formMessageId } = useFormField();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_slot__WEBPACK_IMPORTED_MODULE_2__.Slot, {
        ref: ref,
        id: formItemId,
        "aria-describedby": !error ? `${formDescriptionId}` : `${formDescriptionId} ${formMessageId}`,
        "aria-invalid": !!error,
        ...props
    });
});
FormControl.displayName = "FormControl";
const FormDescription = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>{
    const { formDescriptionId } = useFormField();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        ref: ref,
        id: formDescriptionId,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_4__.cn)("text-[0.8rem] text-slate-500 dark:text-slate-400", className),
        ...props
    });
});
FormDescription.displayName = "FormDescription";
const FormMessage = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, children, ...props }, ref)=>{
    const { error, formMessageId } = useFormField();
    const body = error ? String(error?.message) : children;
    if (!body) {
        return null;
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
        ref: ref,
        id: formMessageId,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_4__.cn)("text-[0.8rem] font-medium text-red-500", className),
        ...props,
        children: body
    });
});
FormMessage.displayName = "FormMessage";


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4196:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export Input */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9834);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_common__WEBPACK_IMPORTED_MODULE_2__]);
_utils_common__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Input = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, type, ...props }, ref)=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
        type: type,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_2__.cn)("flex h-9 w-full rounded-md border border-slate-200 bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-slate-500 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-slate-950 disabled:cursor-not-allowed disabled:opacity-50", className),
        ref: ref,
        ...props
    });
});
Input.displayName = "Input";


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7423:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ Label)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(49);
/* harmony import */ var class_variance_authority__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6926);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9834);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _utils_common__WEBPACK_IMPORTED_MODULE_4__]);
([_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_2__, class_variance_authority__WEBPACK_IMPORTED_MODULE_3__, _utils_common__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const labelVariants = (0,class_variance_authority__WEBPACK_IMPORTED_MODULE_3__.cva)("text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70");
const Label = /*#__PURE__*/ react__WEBPACK_IMPORTED_MODULE_1__.forwardRef(({ className, ...props }, ref)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_radix_ui_react_label__WEBPACK_IMPORTED_MODULE_2__.Root, {
        ref: ref,
        className: (0,_utils_common__WEBPACK_IMPORTED_MODULE_4__.cn)(labelVariants(), className),
        ...props
    }));
Label.displayName = _radix_ui_react_label__WEBPACK_IMPORTED_MODULE_2__.Root.displayName;


__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2148:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6282);
/* harmony import */ var _env_mjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6205);
/* harmony import */ var _server_api_root__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5025);
/* harmony import */ var _server_api_trpc__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7571);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__, _env_mjs__WEBPACK_IMPORTED_MODULE_1__, _server_api_root__WEBPACK_IMPORTED_MODULE_2__, _server_api_trpc__WEBPACK_IMPORTED_MODULE_3__]);
([_trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__, _env_mjs__WEBPACK_IMPORTED_MODULE_1__, _server_api_root__WEBPACK_IMPORTED_MODULE_2__, _server_api_trpc__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




// export API handler
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,_trpc_server_adapters_next__WEBPACK_IMPORTED_MODULE_0__.createNextApiHandler)({
    router: _server_api_root__WEBPACK_IMPORTED_MODULE_2__/* .appRouter */ .q,
    createContext: _server_api_trpc__WEBPACK_IMPORTED_MODULE_3__/* .createTRPCContext */ .uw,
    onError: _env_mjs__WEBPACK_IMPORTED_MODULE_1__/* .env */ .O.NODE_ENV === "development" ? ({ path, error })=>{
        console.error(`❌ tRPC failed on ${path ?? "<no-path>"}: ${error.message}`);
    } : undefined
}));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6707:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   L: () => (/* binding */ joinFormSchema)
/* harmony export */ });
/* unused harmony export default */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7403);
/* harmony import */ var _components_ui_card__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7656);
/* harmony import */ var _components_ui_form__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6984);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9926);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3524);
/* harmony import */ var _prisma_client__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_prisma_client__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1656);
/* harmony import */ var _components_ui_input__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4196);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(1297);
/* harmony import */ var _utils_common__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9834);
/* harmony import */ var _components_ui_chips_group__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2458);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2132);
/* harmony import */ var _radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_radix_ui_react_icons__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(5525);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9771);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _utils_api__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6652);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_16__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ui_card__WEBPACK_IMPORTED_MODULE_1__, _components_ui_form__WEBPACK_IMPORTED_MODULE_2__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, zod__WEBPACK_IMPORTED_MODULE_4__, _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_6__, _components_ui_input__WEBPACK_IMPORTED_MODULE_7__, _components_ui_button__WEBPACK_IMPORTED_MODULE_9__, _utils_common__WEBPACK_IMPORTED_MODULE_10__, _components_ui_chips_group__WEBPACK_IMPORTED_MODULE_11__, _utils_api__WEBPACK_IMPORTED_MODULE_15__]);
([_components_ui_card__WEBPACK_IMPORTED_MODULE_1__, _components_ui_form__WEBPACK_IMPORTED_MODULE_2__, react_hook_form__WEBPACK_IMPORTED_MODULE_3__, zod__WEBPACK_IMPORTED_MODULE_4__, _hookform_resolvers_zod__WEBPACK_IMPORTED_MODULE_6__, _components_ui_input__WEBPACK_IMPORTED_MODULE_7__, _components_ui_button__WEBPACK_IMPORTED_MODULE_9__, _utils_common__WEBPACK_IMPORTED_MODULE_10__, _components_ui_chips_group__WEBPACK_IMPORTED_MODULE_11__, _utils_api__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

















// export const getServerSideProps: GetServerSideProps = async (ctx) => {
//     const session = await getServerAuth(ctx)
//     if (session) {
//         return {
//             redirect: {
//                 destination: "/listing",
//                 permanent: false,
//             }
//         }
//     }
//     return { props: {} }
// }
const joinFormSchema = zod__WEBPACK_IMPORTED_MODULE_4__.z.object({
    name: zod__WEBPACK_IMPORTED_MODULE_4__.z.string({
        required_error: "This field is required."
    }),
    image: zod__WEBPACK_IMPORTED_MODULE_4__.z.string({
        required_error: "Photo required."
    }),
    gender: zod__WEBPACK_IMPORTED_MODULE_4__.z.enum([
        _prisma_client__WEBPACK_IMPORTED_MODULE_5__.Gender.MALE,
        _prisma_client__WEBPACK_IMPORTED_MODULE_5__.Gender.FEMALE
    ], {
        required_error: "This field is required."
    }),
    interest: zod__WEBPACK_IMPORTED_MODULE_4__.z.enum([
        _prisma_client__WEBPACK_IMPORTED_MODULE_5__.UserInterest.MALE,
        _prisma_client__WEBPACK_IMPORTED_MODULE_5__.UserInterest.FEMALE,
        _prisma_client__WEBPACK_IMPORTED_MODULE_5__.UserInterest.BOTH
    ], {
        required_error: "This field is required."
    }),
    password: zod__WEBPACK_IMPORTED_MODULE_4__.z.string({
        required_error: "This field is required."
    }).optional().default("")
});
function Page() {
    const router = useRouter();
    const form = useForm({
        resolver: zodResolver(joinFormSchema),
        mode: "onSubmit",
        shouldFocusError: false
    });
    const { mutateAsync } = trpcClient.users.addNew.useMutation();
    const handleFormSubmit = async (data)=>{
        const res = await mutateAsync({
            ...data,
            image: ""
        });
        if (res) {
            const loginRes = await signIn("credentials", {
                callbackUrl: "/listing",
                redirect: true,
                username: res.username,
                password: res.password
            });
            router.push("/listing");
        }
    };
    return /*#__PURE__*/ _jsx("main", {
        className: " flex min-h-screen flex-col items-center justify-center py-10",
        children: /*#__PURE__*/ _jsx(Card, {
            className: "w-full max-w-screen-md rounded-md bg-white",
            children: /*#__PURE__*/ _jsx(Form, {
                ...form,
                children: /*#__PURE__*/ _jsxs("form", {
                    onSubmit: form.handleSubmit(handleFormSubmit),
                    children: [
                        /*#__PURE__*/ _jsx(CardHeader, {
                            children: /*#__PURE__*/ _jsx(CardTitle, {
                                className: "text-xl text-center font-bold text-pink-500",
                                children: "Join the pool of singles at this wedding."
                            })
                        }),
                        /*#__PURE__*/ _jsx(CardContent, {
                            children: /*#__PURE__*/ _jsxs("div", {
                                className: "space-y-5",
                                children: [
                                    /*#__PURE__*/ _jsx(FormField, {
                                        control: form.control,
                                        name: "name",
                                        render: ({ field, fieldState })=>/*#__PURE__*/ _jsxs(FormItem, {
                                                children: [
                                                    /*#__PURE__*/ _jsx(FormLabel, {
                                                        children: "Your Name"
                                                    }),
                                                    /*#__PURE__*/ _jsx(FormControl, {
                                                        children: /*#__PURE__*/ _jsx(Input, {
                                                            ...field
                                                        })
                                                    }),
                                                    fieldState.error && /*#__PURE__*/ _jsx(FormMessage, {})
                                                ]
                                            })
                                    }),
                                    /*#__PURE__*/ _jsx(FormField, {
                                        control: form.control,
                                        name: "gender",
                                        render: ({ field, fieldState })=>/*#__PURE__*/ _jsxs(FormItem, {
                                                children: [
                                                    /*#__PURE__*/ _jsx(FormLabel, {
                                                        children: "Gender"
                                                    }),
                                                    /*#__PURE__*/ _jsx(FormControl, {
                                                        children: /*#__PURE__*/ _jsx(ChipsGroup, {
                                                            value: field.value,
                                                            onChange: (value)=>{
                                                                form.setValue("interest", value === "MALE" ? "FEMALE" : "MALE");
                                                                field.onChange(value);
                                                            },
                                                            options: [
                                                                Gender.MALE,
                                                                Gender.FEMALE
                                                            ]
                                                        })
                                                    }),
                                                    fieldState.error && /*#__PURE__*/ _jsx(FormMessage, {})
                                                ]
                                            })
                                    }),
                                    /*#__PURE__*/ _jsx(FormField, {
                                        control: form.control,
                                        name: "interest",
                                        render: ({ field, fieldState })=>/*#__PURE__*/ _jsxs(FormItem, {
                                                children: [
                                                    /*#__PURE__*/ _jsx(FormLabel, {
                                                        children: "Interested in"
                                                    }),
                                                    /*#__PURE__*/ _jsx(FormControl, {
                                                        children: /*#__PURE__*/ _jsx(ChipsGroup, {
                                                            value: field.value,
                                                            onChange: (value)=>field.onChange(value),
                                                            options: [
                                                                UserInterest.MALE,
                                                                UserInterest.FEMALE,
                                                                UserInterest.BOTH
                                                            ]
                                                        })
                                                    }),
                                                    fieldState.error && /*#__PURE__*/ _jsx(FormMessage, {})
                                                ]
                                            })
                                    }),
                                    /*#__PURE__*/ _jsx(FormField, {
                                        control: form.control,
                                        name: "image",
                                        render: ({ field, fieldState })=>/*#__PURE__*/ _jsxs(FormItem, {
                                                children: [
                                                    /*#__PURE__*/ _jsx(FormLabel, {
                                                        children: "Photo"
                                                    }),
                                                    /*#__PURE__*/ _jsx(FormControl, {
                                                        children: /*#__PURE__*/ _jsx(PhotoInputComponent, {
                                                            value: field.value,
                                                            onChange: (value)=>field.onChange(value)
                                                        })
                                                    }),
                                                    fieldState.error && /*#__PURE__*/ _jsx(FormMessage, {})
                                                ]
                                            })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ _jsxs(CardFooter, {
                            className: "flex items-center justify-between",
                            children: [
                                /*#__PURE__*/ _jsx("div", {}),
                                /*#__PURE__*/ _jsx(Button, {
                                    type: "submit",
                                    className: "bg-opacity-90",
                                    children: form.formState.isSubmitting ? /*#__PURE__*/ _jsx("span", {
                                        className: "w-5 h-5 border-2 border-white rounded-full border-t-transparent animate-spin"
                                    }) : "Continue"
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
}
function blobToBase64(blob) {
    return new Promise((resolve, _)=>{
        const reader = new FileReader();
        reader.onloadend = ()=>resolve(reader.result?.toString() ?? "");
        reader.readAsDataURL(blob);
    });
}
function PhotoInputComponent({ value, onChange }) {
    const inputRef = useRef(null);
    const [capturedPhoto, setCapturedPhoto] = useState();
    const filesChangeHandler = async (e)=>{
        const files = e.target.files;
        const firstFile = files?.[0];
        if (!firstFile) return;
        const imageB64 = await blobToBase64(firstFile);
        onChange?.(imageB64);
    };
    useEffect(()=>{
        setCapturedPhoto(value);
    }, [
        value
    ]);
    return /*#__PURE__*/ _jsxs("div", {
        children: [
            /*#__PURE__*/ _jsx("input", {
                type: "file",
                ref: inputRef,
                onChange: filesChangeHandler,
                hidden: true,
                accept: "image/*",
                className: "hidden",
                capture: "user"
            }),
            /*#__PURE__*/ _jsx("button", {
                type: "button",
                onClick: ()=>inputRef.current?.click(),
                className: cn("rounded-full border aspect-square h-32 w-32 border-slate-200 flex items-center justify-center overflow-hidden", !capturedPhoto && "p-5"),
                children: capturedPhoto ? /*#__PURE__*/ _jsx(Image, {
                    src: capturedPhoto,
                    alt: "",
                    width: 100,
                    height: 100,
                    className: "w-full h-full object-cover object-center"
                }) : /*#__PURE__*/ _jsx(AvatarIcon, {
                    className: "w-20 h-20"
                })
            })
        ]
    });
} // type PhotoInputComponentProps = {
 //     value?: string | null;
 //     onChange?: (value: string) => void;
 // }
 // function PhotoInputComponent({ value, onChange }: PhotoInputComponentProps) {
 //     const inputRef = useRef<HTMLInputElement>(null);
 //     const [popupOpen, setPopupOpen] = useState(false);
 //     const [capturedPhoto, setCapturedPhoto] = useState<string | null>();
 //     const webcamRef = useRef<Webcam>(null);
 //     const capture = useCallback(
 //         () => {
 //             const imageSrc = webcamRef.current?.getScreenshot();
 //             setCapturedPhoto(imageSrc)
 //         },
 //         [webcamRef]
 //     );
 //     const filesChangeHandler = (e: ChangeEvent<HTMLInputElement>) => {
 //         const files = e.target.files;
 //         if (!files || files.length <= 0) return;
 //         console.log(files[0])
 //     }
 //     useEffect(() => {
 //         setCapturedPhoto(value)
 //     }, [value])
 //     const handleContinueClick = () => {
 //         if (!capturedPhoto) return;
 //         onChange?.(capturedPhoto)
 //         setPopupOpen(false)
 //     }
 //     return (
 //         <div>
 //             <input
 //                 type="file"
 //                 ref={inputRef}
 //                 onChange={filesChangeHandler}
 //                 hidden
 //                 className="hidden"
 //                 capture="user" />
 //             <Dialog
 //                 open={popupOpen}
 //                 onOpenChange={(value) => {
 //                     setCapturedPhoto(null)
 //                     setPopupOpen(value)
 //                 }}>
 //                 <DialogTrigger asChild>
 //                     <button type="button" className={cn(
 //                         "rounded-full border aspect-square h-32 w-32 border-slate-200 flex items-center justify-center overflow-hidden",
 //                         !capturedPhoto && "p-5"
 //                     )}>
 //                         {
 //                             capturedPhoto ?
 //                                 <Image src={capturedPhoto} alt="" width={100} height={100} className="w-full h-full object-cover object-center" />
 //                                 :
 //                                 <AvatarIcon className="w-20 h-20" />
 //                         }
 //                     </button>
 //                 </DialogTrigger>
 //                 <DialogContent className="sm:max-w-4xl p-0 overflow-hidden bg-white">
 //                     <div className="relative max-h-[95vh]">
 //                         {
 //                             capturedPhoto ?
 //                                 <div>
 //                                     <Image src={capturedPhoto} alt="" width={500} height={800} className="w-full h-full object-contain object-center" />
 //                                     <div className="absolute left-1/2 -translate-x-1/2 bottom-3 z-[10] flex items-center justify-center gap-4 w-full">
 //                                         <Button
 //                                             type="button"
 //                                             variant="dark"
 //                                             onClick={() => setCapturedPhoto(null)}
 //                                             className="text-white rounded-full h-auto text-xs md:text-sm">
 //                                             Capture again
 //                                         </Button>
 //                                         <Button onClick={handleContinueClick} type="button" variant="default" className="text-white rounded-full text-xs h-auto md:text-sm">
 //                                             Continue
 //                                         </Button>
 //                                     </div>
 //                                 </div>
 //                                 :
 //                                 <div className="w-full">
 //                                     <Webcam
 //                                         audio={false}
 //                                         height={800}
 //                                         screenshotFormat="image/jpeg"
 //                                         capture="user"
 //                                         ref={webcamRef}
 //                                         width={800}
 //                                         className="object-cover h-full object-center w-full"
 //                                         videoConstraints={{ facingMode: "user", aspectRatio: { exact: 1 } }}
 //                                     />
 //                                     <Button onClick={capture} type="button" variant="default" className="absolute left-1/2 -translate-x-1/2 bottom-3 z-[10] text-white rounded-full text-xs md:text-sm">
 //                                         Capture
 //                                     </Button>
 //                                 </div>
 //                         }
 //                     </div>
 //                 </DialogContent>
 //             </Dialog>
 //         </div>
 //     )
 // }

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5025:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   q: () => (/* binding */ appRouter)
/* harmony export */ });
/* harmony import */ var _server_api_trpc__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7571);
/* harmony import */ var _routers_users__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3414);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_server_api_trpc__WEBPACK_IMPORTED_MODULE_0__, _routers_users__WEBPACK_IMPORTED_MODULE_1__]);
([_server_api_trpc__WEBPACK_IMPORTED_MODULE_0__, _routers_users__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


const appRouter = (0,_server_api_trpc__WEBPACK_IMPORTED_MODULE_0__/* .createTRPCRouter */ .hA)({
    users: _routers_users__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3414:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _server_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7550);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9926);
/* harmony import */ var _trpc__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7571);
/* harmony import */ var _pages_join__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6707);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_server_auth__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_1__, _trpc__WEBPACK_IMPORTED_MODULE_2__, _pages_join__WEBPACK_IMPORTED_MODULE_3__]);
([_server_auth__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_1__, _trpc__WEBPACK_IMPORTED_MODULE_2__, _pages_join__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const usersPaginationInput = zod__WEBPACK_IMPORTED_MODULE_1__.z.object({
    page: zod__WEBPACK_IMPORTED_MODULE_1__.z.number(),
    perPage: zod__WEBPACK_IMPORTED_MODULE_1__.z.number()
}).optional().default({
    page: 1,
    perPage: 20
});
const usersRouter = (0,_trpc__WEBPACK_IMPORTED_MODULE_2__/* .createTRPCRouter */ .hA)({
    getByInterest: _trpc__WEBPACK_IMPORTED_MODULE_2__/* .protectedProcedure */ .U5.input(usersPaginationInput).query(async ({ ctx, input })=>{
        const { db, session } = ctx;
        const authUser = await (0,_server_auth__WEBPACK_IMPORTED_MODULE_0__/* .getAuthUser */ .nX)(session);
        if (!authUser) return [];
        const { perPage, page } = input;
        return await db.user.findMany({
            where: {
                ...authUser.interest !== "BOTH" && {
                    gender: authUser.interest
                },
                id: {
                    not: authUser.id
                }
            },
            orderBy: {
                "name": "asc"
            },
            ...perPage !== -1 && {
                take: perPage,
                skip: page <= 1 ? 0 : (page - 1) * perPage
            }
        });
    }),
    me: _trpc__WEBPACK_IMPORTED_MODULE_2__/* .protectedProcedure */ .U5.query(async ({ ctx })=>{
        const { db, session } = ctx;
        if (!session) return null;
        return await db.user.findUnique({
            where: {
                id: session.user.id
            }
        });
    }),
    getById: _trpc__WEBPACK_IMPORTED_MODULE_2__/* .protectedProcedure */ .U5.input(zod__WEBPACK_IMPORTED_MODULE_1__.z.object({
        id: zod__WEBPACK_IMPORTED_MODULE_1__.z.string()
    })).query(async ({ input, ctx })=>{
        const { db, session } = ctx;
        if (!session) return null;
        return await db.user.findUnique({
            where: {
                id: input.id
            }
        });
    }),
    addNew: _trpc__WEBPACK_IMPORTED_MODULE_2__/* .publicProcedure */ .$y.input(_pages_join__WEBPACK_IMPORTED_MODULE_3__/* .joinFormSchema */ .L).mutation(async ({ ctx, input })=>{
        const { db } = ctx;
        try {
            const user = await db.user.create({
                data: {
                    gender: input.gender,
                    image: input.image,
                    interest: input.interest,
                    name: input.name,
                    password: input.password,
                    username: `${input.name.toLowerCase().replaceAll(" ", "_")}${Math.random() * 99999}`
                }
            });
            if (!user) throw new Error();
            return user;
        } catch (error) {
            console.log(error);
            return null;
        }
    })
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (usersRouter);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7571:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   $y: () => (/* binding */ publicProcedure),
/* harmony export */   U5: () => (/* binding */ protectedProcedure),
/* harmony export */   hA: () => (/* binding */ createTRPCRouter),
/* harmony export */   uw: () => (/* binding */ createTRPCContext)
/* harmony export */ });
/* harmony import */ var _trpc_server__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2937);
/* harmony import */ var superjson__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(72);
/* harmony import */ var superjson__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(superjson__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var zod__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9926);
/* harmony import */ var _server_auth__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7550);
/* harmony import */ var _server_db__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5495);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc_server__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_2__, _server_auth__WEBPACK_IMPORTED_MODULE_3__, _server_db__WEBPACK_IMPORTED_MODULE_4__]);
([_trpc_server__WEBPACK_IMPORTED_MODULE_0__, zod__WEBPACK_IMPORTED_MODULE_2__, _server_auth__WEBPACK_IMPORTED_MODULE_3__, _server_db__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





/**
 * This helper generates the "internals" for a tRPC context. If you need to use it, you can export
 * it from here.
 *
 * Examples of things you may need it for:
 * - testing, so we don't have to mock Next.js' req/res
 * - tRPC's `createSSGHelpers`, where we don't have req/res
 *
 * @see https://create.t3.gg/en/usage/trpc#-serverapitrpcts
 */ const createInnerTRPCContext = (opts)=>{
    return {
        session: opts.session,
        db: _server_db__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z
    };
};
/**
 * This is the actual context you will use in your router. It will be used to process every request
 * that goes through your tRPC endpoint.
 *
 * @see https://trpc.io/docs/context
 */ const createTRPCContext = async (opts)=>{
    const { req, res } = opts;
    // Get the session from the server using the getServerSession wrapper function
    const session = await (0,_server_auth__WEBPACK_IMPORTED_MODULE_3__/* .getServerAuth */ .Fh)({
        req,
        res
    });
    return createInnerTRPCContext({
        session
    });
};
/**
 * 2. INITIALIZATION
 *
 * This is where the tRPC API is initialized, connecting the context and transformer. We also parse
 * ZodErrors so that you get typesafety on the frontend if your procedure fails due to validation
 * errors on the backend.
 */ const t = _trpc_server__WEBPACK_IMPORTED_MODULE_0__.initTRPC.context().create({
    transformer: (superjson__WEBPACK_IMPORTED_MODULE_1___default()),
    errorFormatter ({ shape, error }) {
        return {
            ...shape,
            data: {
                ...shape.data,
                zodError: error.cause instanceof zod__WEBPACK_IMPORTED_MODULE_2__.ZodError ? error.cause.flatten() : null
            }
        };
    }
});
/**
 * 3. ROUTER & PROCEDURE (THE IMPORTANT BIT)
 *
 * These are the pieces you use to build your tRPC API. You should import these a lot in the
 * "/src/server/api/routers" directory.
 */ /**
 * This is how you create new routers and sub-routers in your tRPC API.
 *
 * @see https://trpc.io/docs/router
 */ const createTRPCRouter = t.router;
/**
 * Public (unauthenticated) procedure
 *
 * This is the base piece you use to build new queries and mutations on your tRPC API. It does not
 * guarantee that a user querying is authorized, but you can still access user session data if they
 * are logged in.
 */ const publicProcedure = t.procedure;
/** Reusable middleware that enforces users are logged in before running the procedure. */ const enforceUserIsAuthed = t.middleware(({ ctx, next })=>{
    if (!ctx.session?.user) {
        throw new _trpc_server__WEBPACK_IMPORTED_MODULE_0__.TRPCError({
            code: "UNAUTHORIZED"
        });
    }
    return next({
        ctx: {
            // infers the `session` as non-nullable
            session: {
                ...ctx.session,
                user: ctx.session.user
            }
        }
    });
});
/**
 * Protected (authenticated) procedure
 *
 * If you want a query or mutation to ONLY be accessible to logged in users, use this. It verifies
 * the session is valid and guarantees `ctx.session.user` is not null.
 *
 * @see https://trpc.io/docs/procedures
 */ const protectedProcedure = t.procedure.use(enforceUserIsAuthed);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6652:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export trpcClient */
/* harmony import */ var _trpc_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(272);
/* harmony import */ var _trpc_next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7455);
/* harmony import */ var superjson__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(72);
/* harmony import */ var superjson__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(superjson__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _env_mjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6205);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_trpc_client__WEBPACK_IMPORTED_MODULE_0__, _trpc_next__WEBPACK_IMPORTED_MODULE_1__, _env_mjs__WEBPACK_IMPORTED_MODULE_3__]);
([_trpc_client__WEBPACK_IMPORTED_MODULE_0__, _trpc_next__WEBPACK_IMPORTED_MODULE_1__, _env_mjs__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/**
 * This is the client-side entrypoint for your tRPC API. It is used to create the `api` object which
 * contains the Next.js App-wrapper, as well as your type-safe React Query hooks.
 *
 * We also create a few inference helpers for input and output types.
 */ 



const getBaseUrl = ()=>{
    if (false) {} // browser should use relative url
    return `${_env_mjs__WEBPACK_IMPORTED_MODULE_3__/* .env */ .O.BASE_URL}${process.env.PORT ?? 3000}`; // dev SSR should use localhost
};
/** A set of type-safe react-query hooks for your tRPC API. */ const trpcClient = (0,_trpc_next__WEBPACK_IMPORTED_MODULE_1__.createTRPCNext)({
    config () {
        return {
            /**
       * Transformer used for data de-serialization from the server.
       *
       * @see https://trpc.io/docs/data-transformers
       */ transformer: (superjson__WEBPACK_IMPORTED_MODULE_2___default()),
            /**
       * Links used to determine request flow from client to server.
       *
       * @see https://trpc.io/docs/links
       */ links: [
                (0,_trpc_client__WEBPACK_IMPORTED_MODULE_0__.loggerLink)({
                    enabled: (opts)=> false || opts.direction === "down" && opts.result instanceof Error
                }),
                (0,_trpc_client__WEBPACK_IMPORTED_MODULE_0__.httpBatchLink)({
                    url: `${getBaseUrl()}/api/trpc`
                })
            ]
        };
    },
    ssr: false
});

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9834:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cn: () => (/* binding */ cn)
/* harmony export */ });
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6593);
/* harmony import */ var tailwind_merge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8097);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__]);
([clsx__WEBPACK_IMPORTED_MODULE_0__, tailwind_merge__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


function cn(...inputs) {
    return (0,tailwind_merge__WEBPACK_IMPORTED_MODULE_1__.twMerge)((0,clsx__WEBPACK_IMPORTED_MODULE_0__.clsx)(inputs));
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [172,669,550], () => (__webpack_exec__(6816)));
module.exports = __webpack_exports__;

})();